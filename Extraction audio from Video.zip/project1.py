import moviepy.editor
from tkinter.filedialog import askopenfilename
from tkinter import *

window = Tk()
window.geometry("700x400")
window.title("Muhammad Awais")

# Title Label
Label(window, text="VIDEO TO AUDIO CONVERTER", bg='orange', font=('Calibri 15')).pack()
Label(window, text="Choose a File ").pack()

def browse():
    global video_path, video  # Global to use in 'save' function
    video_path = askopenfilename(filetypes=[("Video Files", "*.mp4;*.avi;*.mov;*.mkv")])  # File dialog filters for video files
    if video_path:
        video = moviepy.editor.VideoFileClip(video_path)  # Load the video file
        pathlab.config(text=video_path)  # Show the file path in the label

def save():
    try:
        audio = video.audio  # Extract audio from the video
        audio.write_audiofile("sample.wav")  # Save the audio as a WAV file
        Label(window, text="Video Converted into Audio and Saved Successfully", bg='blue', font=('Calibri 15')).pack()
    except NameError:
        Label(window, text="No video file selected.", bg='red', font=('Calibri 15')).pack()  # Error if no video is selected
    except Exception as e:
        Label(window, text=f"Error: {str(e)}", bg='red', font=('Calibri 15')).pack()  # Generic error handler

pathlab = Label(window)
pathlab.pack()

# Creating buttons
Button(window, text='Browse', command=browse).pack()
Button(window, text='SAVE', command=save).pack()

window.mainloop()
